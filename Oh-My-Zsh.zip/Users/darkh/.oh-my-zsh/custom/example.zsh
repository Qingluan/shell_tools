# Add yourself some shortcuts to projects you often work on
# Example:
#
# brainstormr=/Users/robbyrussell/Projects/development/planetargon/brainstormr
#

[[ -s /usr/local/etc/autojump.sh ]] && . /usr/local/etc/autojump.sh
alias lg="ls ./ | grep "
alias updatedb="sudo  sh /usr/libexec/locate.updatedb"

export PATH=/usr/local/sbin:$PATH

alias ipy2="ipython2"
alias h='history';
export TORSOCKS_CONF_FILE=/etc/torsocks.conf
alias f='proxychains4' 

function  Download {
	f wget -c -t 10 $1 && python -c "print '\a\a\a'" ;
}
